package com.example.pr14
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var trueButton: Button
    private lateinit var falseButton: Button
    private lateinit var questionTextView: TextView
    private lateinit var nextButton : Button
    private lateinit var backButton : Button
    private var currentIndex =0

    private val questionBank = listOf(
        numQuest(R.string.question_text1,true),
        numQuest(R.string.question_text2,true),
        numQuest(R.string.question_text3,true),
        numQuest(R.string.question_text4,true),
        numQuest(R.string.question_text5,true),
        numQuest(R.string.question_text6,true),
        numQuest(R.string.question_text7,true)
    )
    private fun cheackAnswer(userAnswer : Boolean){
        val correctAnswer = questionBank[currentIndex].answer
        if(userAnswer == correctAnswer){
            R.string.true_button
        }else{
            "Не правильно!"
        }

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        trueButton = findViewById(R.id.true_button)
        falseButton = findViewById(R.id.false_button)
        nextButton = findViewById(R.id.next_button)
        backButton = findViewById(R.id.back_button)
        questionTextView = findViewById(R.id.question_text1)

        trueButton.setOnClickListener{view: View ->
            val toast = Toast.makeText(this, "Правильно!", Toast.LENGTH_SHORT)
            toast.setGravity(Gravity.TOP, 0,240)
            toast.show()
            checkAnswer(true)
        }
        falseButton.setOnClickListener{view: View ->
            val toast1 = Toast.makeText(this, "Не правильно!", Toast.LENGTH_SHORT)
            toast1.setGravity(Gravity.TOP,0,240)
            toast1.show()
            cheackAnswer(false)
        }
        val questionTextResId = questionBank[currentIndex].textResId
        questionTextView.setText(questionTextResId)
        nextButton.setOnClickListener{
            currentIndex =(currentIndex+1)%questionBank.size
            updateQuestion()
        }
        backButton.setOnClickListener{
            currentIndex =(currentIndex-1)%questionBank.size
            updateQuestion()
        }
    }
    private fun updateQuestion(){
        val questionTextResId = questionBank[currentIndex].textResId
        questionTextView.setText(questionTextResId)
    }
    private fun checkAnswer(userAnswer:Boolean) {
        val correctAnswer = questionBank[currentIndex].answer
        if(userAnswer==correctAnswer){
            Toast.makeText(this,R.string.trues,Toast.LENGTH_SHORT).show()
            currentIndex=(currentIndex+1)%questionBank.size
            updateQuestion()
        }else{
            Toast.makeText(this,R.string.falses,Toast.LENGTH_SHORT).show()
        }
    }

}