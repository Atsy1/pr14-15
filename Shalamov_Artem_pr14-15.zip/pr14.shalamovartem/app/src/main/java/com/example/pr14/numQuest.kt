package com.example.pr14

import android.support.annotation.StringRes

class numQuest (@StringRes val textResId: Int,val answer: Boolean){}